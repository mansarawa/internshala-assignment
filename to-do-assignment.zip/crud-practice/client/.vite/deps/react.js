import {
  require_react
} from "./chunk-UPDK7Z2H.js";
export default require_react();
//# sourceMappingURL=react.js.map
