
import React, { useState } from 'react'
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import Navbar from './layout/Navbar.jsx'
import TextBox from './layout/TextBox.jsx';
import Register from './layout/Register.jsx';


import Login from './layout/Login.jsx';

import Update from './layout/Update.jsx';
import MyTasks from './layout/MyTasks.jsx';


const App = () => {
  const user = JSON.parse(localStorage.getItem('user'))
  const [mode,setMode]=useState('light')
  const handlemode=()=>{
    if(mode=='light')
    {
      setMode('dark')
     
    }
    else
    {
      setMode('light')
      
    }
  }
  return (
    <>
 
      <BrowserRouter style={{width:'100%',hegiht:'100%'}}>
      <Navbar title="To-Do" mode={mode} handlemode={handlemode}/>
        <Routes>
          <Route path='/register'  element={<Register mode={mode}/>}/>
         
          <Route path='/login' element={<Login mode={mode}/>}/>
          
          <Route path='/mynotes' element={<MyTasks mode={mode}/>}/>
          <Route path='/update/:id/:heading/:desc' element={<Update mode={mode}/>}/>
          {user?<Route path='/' element={<TextBox title="Enter Task To Add" mode={mode}/>}/>
          :<Route   element={<Login mode={mode}/>}/>}
        </Routes>
        
      </BrowserRouter>
      
    </>
  )
}

export default App
